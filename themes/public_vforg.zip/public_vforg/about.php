<?php if (!defined('APPLICATION')) exit();

$ThemeInfo['VanillaForums.org'] = array(
   'Description' => "A custom theme for VanillaForums.org. Shiny and blue!",
   'Version' => '1.0',
   'Author' => "Mark O'Sullivan",
   'AuthorEmail' => 'mark@vanillaforums.com',
   'AuthorUrl' => 'http://markosullivan.ca'
);